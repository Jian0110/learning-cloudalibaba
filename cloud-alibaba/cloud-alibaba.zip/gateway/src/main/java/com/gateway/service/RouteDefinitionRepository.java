package com.gateway.service;

import org.springframework.cloud.gateway.route.InMemoryRouteDefinitionRepository;

public class RouteDefinitionRepository extends InMemoryRouteDefinitionRepository {
}
