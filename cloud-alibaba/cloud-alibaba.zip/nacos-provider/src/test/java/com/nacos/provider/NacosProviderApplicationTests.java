package com.nacos.provider;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NacosProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
