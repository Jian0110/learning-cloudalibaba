package com.nacos.consumer.common.enums;

public interface IResponseEnum {
    String getCode();
    String getMessage();
}
